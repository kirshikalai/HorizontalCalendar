# HorizontalCalendarAndroid
A material horizontal calendar view for Android based on RecyclerView.<br>
Easy and simple to implement<br>
Just clone the repository and use it in your way

![showcase](/assets/horizontal-calendar.gif)


## Contributing

Contributions are welcome, feel free to submit a pull request.

## Author
Maintained by [Tejas Soni](https://www.github.com/Tejas-Soni)

##### Connect with me: 
<br>

  <a href="www.linkedin.com/in/tejas-100ni">
    <img align="left" alt="Tejas Soni | Linkedin" width="24px" src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Linkedin.svg" />
  </a>
  <a href="https://twitter.com/tejashsoni">
    <img align="left" alt="Tejas Soni | Twitter" width="26px" src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Twitter.svg" />
  </a>
  <a href="https://www.instagram.com/tejas_100ni/">
    <img align="left" alt="Tejas Soni | Instagram" width="24px" src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Instagram.svg" />
  </a>
  <a href="mailto:tejashsoni51331@gmail.com">
    <img align="left" alt="Tejas Soni | Gmail" width="26px" src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Gmail.svg" />
  </a>

<br><br>

![visitors](https://visitor-badge.glitch.me/badge?page_id=Tejas-Soni.HorizontalCalendarAndroid)
